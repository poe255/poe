def multiplication(nbr):

	for i in range(11):
			print(nbr," x ", i, " = ", nbr*i)

def table():
	for i in range(11):
		multiplication(i)

table()